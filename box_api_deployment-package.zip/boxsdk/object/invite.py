from .base_object import BaseObject


class Invite(BaseObject):
    """Represents the invite"""

    _item_type = 'invite'
