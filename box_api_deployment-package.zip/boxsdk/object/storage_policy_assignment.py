from .base_object import BaseObject


class StoragePolicyAssignment(BaseObject):
    """Represents the storage policy assignment"""

    _item_type = 'storage_policy_assignment'
