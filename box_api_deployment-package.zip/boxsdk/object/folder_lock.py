from .base_object import BaseObject


class FolderLock(BaseObject):
    """Represents the folder lock"""

    _item_type = 'folder_lock'
